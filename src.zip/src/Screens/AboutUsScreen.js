import React from 'react'

const AboutUsScreen = () => {
    return (
        <div>
            AboutUsScreen
        </div>
    )
}

export default AboutUsScreen
